// Type declarations for Ethereum/MetaMask in the window object
interface Window {
  ethereum: any;
}
